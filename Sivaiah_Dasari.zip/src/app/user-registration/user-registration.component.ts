import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../shared/common-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css'],
})
export class UserRegistrationComponent implements OnInit {
  registrationForm: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private commonService: CommonService,
    private router: Router,

  ) {}

  ngOnInit(): void {
    this.createRegistrationForm();
  }

  onSubmit(): void {
    console.log(this.registrationForm.value);
    this.router.navigate(['/login']);
  }

  onItemChange(value) {
    this.registrationForm.controls.Gender.setValue(value);
  }

  createRegistrationForm() {
    this.registrationForm = this.formBuilder.group({
      // tslint:disable-next-line: max-line-length
      FirstName: [
        '',
        [
          Validators.required,          
        ],
      ],
      LastName: ['', [Validators.required]],
      EmailId: ['', [Validators.required, Validators.pattern(this.commonService.REGULAREXPRESSIONS.Email_Regex)]],
      MobileNo: ['', [Validators.required, Validators.pattern(this.commonService.REGULAREXPRESSIONS.NumberOnly)]],
      Gender: ['', [Validators.required]],
      Address: ['', [Validators.required]],
      Password: ['', [Validators.required, Validators.pattern(this.commonService.REGULAREXPRESSIONS.Password)]],
      ConfirmPassword: ['', [Validators.required]],
    }, { validators : this.commonService.checkPasswords });
  }
}
