import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup } from '@angular/forms';

@Injectable({ providedIn: 'root' })
export class CommonService {
  constructor() {}
  REGULAREXPRESSIONS = {
    TextOnly: '[a-zA-Z ]*',
    NumberOnly: '^[0-9]*$',
    AlphaNumeric: '^[A-Za-z0-9_]*$',
    IpAddress:
      '^(d|[1-9]d|1dd|2([0-4]d|5[0-5])).(d|[1-9]d|1dd|2([0-4]d|5[0-5])).(d|[1-9]d|1dd|2([0-4]d|5[0-5])).(d|[1-9]d|1dd|2([0-4]d|5[0-5]))*$', // "[^0-9\.]"
    DateTime:
      '^((0?[1-9]|1[012])[/](0?[1-9]|[12][0-9]|3[01])[/](19|20)?[0-9][0-9][0-9]{2})*$',
    AlphaNumericSpecial_Regex: '^[a-zA-Z0-9-_ ]+$',
    AlphaNumericSpecial_More_Regex: '^[a-zA-Z0-9-.,_@ ]+$',
    MACAddress_Regex: '^[a-zA-Z0-9-]+$',
    IpAddress_Regex:
      '^([0-9]{1,3})[.]([0-9]{1,3})[.]([0-9]{1,3})[.]([0-9]{1,3})$',
    PortNumber_Regex:
      '^([0-9]{1,4}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])$',
    Decimals_Regex: '[0-9]+(.[0-9][0-9]?[0-9]?[0-9]?)?',
    Email_Regex: '^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$',
    Website_Regex:
      '^(http://|https://)?(www.)?([a-zA-Z0-9]+).[a-zA-Z0-9]*.[a-z]{2}.?([a-z]+)?$',
    NegativeNumber_Regex: '-?[0-9]+(.[0-9][0-9]?[0-9]?[0-9]?)?',
    Password: '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$',
    AlphaNumericSpecial_More_Regex_without_space: '^[a-zA-Z0-9-.,_@S]+$',
  };

  checkPasswords(group: FormGroup) {
    
    let pass = group.get('Password').value;
    let confirmPass = group.get('ConfirmPassword').value;

    return pass === confirmPass ? null : { notSame: true };
  }
}
