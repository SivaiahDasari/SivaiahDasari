import { Component, OnInit } from '@angular/core';
import { FileUploadService } from '../services/file-upload.service';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css'],
})
export class FileUploadComponent implements OnInit {
  fileToUpload: File;
  previewString: string;
  constructor(private fileUploadService: FileUploadService) {}

  ngOnInit(): void {}

  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
  }

  downloadFile(): void {
    this.previewString = this.fileUploadService.getFile();
    const linkSource = 'data:application/pdf;base64,' + this.previewString;
    const downloadLink = document.createElement('a');
    const fileName = 'fileName.pdf';
    downloadLink.href = linkSource;
    downloadLink.download = fileName;
    downloadLink.click();
  }

  uploadFile(): void {
    this.fileUploadService
      .uploadFile(this.fileToUpload)
      .subscribe((response: any) => {
        if (response) {
          // show success message
        }
      });
  }
}
