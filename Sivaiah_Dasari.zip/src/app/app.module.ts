import { FileUploadService } from './services/file-upload.service';
import { UserService } from './services/user.service';
import { AppRoutingModule } from './routing-module.module';
import { CommonService } from './shared/common-service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { LoginComponent } from './login/login.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    UserRegistrationComponent,
    LoginComponent,
    UserDetailsComponent,
    FileUploadComponent,
  ],
  imports: [BrowserModule, ReactiveFormsModule, AppRoutingModule, HttpClientModule],
  providers: [CommonService, UserService, FileUploadService],
  bootstrap: [AppComponent],
})
export class AppModule {}
