import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../shared/common-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;

  constructor(private formBuilder: FormBuilder,
              private commonService: CommonService,
              private router: Router) {}

  ngOnInit(): void {
    this.createLoginForm();
  }

  // tslint:disable-next-line: typedef
  createLoginForm() {
      this.loginForm = this.formBuilder.group({
        // tslint:disable-next-line: max-line-length
        emailId: ['', [Validators.required, Validators.maxLength(50), Validators.pattern(this.commonService.REGULAREXPRESSIONS.Email_Regex)]],
        password: ['', [Validators.required, Validators.minLength(8), Validators.pattern(this.commonService.REGULAREXPRESSIONS.Password)]],
      });
  }

  // tslint:disable-next-line: typedef
  onSubmit() {
    if(this.loginForm.valid) {
      console.log(this.loginForm.value);
      this.router.navigate(['/user-details']);
    }
    
  }
}
